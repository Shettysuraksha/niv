# git-secret
-This project works perfectly fine to prevent you from committing secrets and credentials into Git repositories that are specific to AWS and GCP
-To start, clone the git-secrets repo to your local machine

$git clone https://github.com/deshpandetanmay/git-secrets.git
$cd git-secrets/

-Once installed, you need to go to the Git repo where you need to use this utility. For the demo, I am cloning another repo from my GitHub

$git clone https://github.com/suraksha-niveus/git-secret.git
$cd git-secret/

-install git secrets for this repo, you can run the following command

$git secrets --install

-This will install the executables for secrets to scan and it will also install three Hooks for this repo
✓ Installed commit-msg hook to .git/hooks/commit-msg
✓ Installed pre-commit hook to .git/hooks/pre-commit
✓ Installed prepare-commit-msg hook to .git/hooks/prepare-commit-msg

-To install AWS and GCP specific checks

$git secrets --register-aws
$git secrets --register-gcp

-To test if everything is working as expected, I created a service JSON account from GCP and copied it into my repo
-i.e credentiales_example.json

-Now, when I run the git commit command, I see

$git commit -m "Updated config"
credentiales_example.json:4:    "private_key_id": "xxxxxxxxxxxxxxxxxxxxxxxxxxxxxxx",
credentiales_example.json:5:    "private_key": "-----BEGIN PRIVATE KEY-----\nxxxxxxxxxxxxxxxxxxxxxxxxxxx\n-----END PRIVATE KEY-----\n",

[ERROR] Matched one or more prohibited patterns

Possible mitigations:
- Mark false positives as allowed using: git config --add secrets.allowed ...
- Mark false positives as allowed by adding regular expressions to .gitallowed at repository's root directory
- List your configured patterns: git config --get-all secrets.patterns
- List your configured allowed patterns: git config --get-all secrets.allowed
- List your configured allowed patterns in .gitallowed at repository's root directory
- Use --no-verify if this is a one-time false positive


-run the following command to ignore the checks and proceed with commits

$git commit -m "Updated config" --no-verify
