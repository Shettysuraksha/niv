**TruffleHog**

**install** 
----$brew tap trufflesecurity/trufflehog
----$brew install trufflehog

**scan**
----$trufflehog git https://github.com/suraksha-niveus/scan.git

**Result**

🐷🔑🐷  TruffleHog. Unearth your secrets. 🐷🔑🐷

Found unverified result 🐷🔑❓
Detector Type: GCP
Raw result: xxxxxxxxx-compute@developer.gserviceaccount.com
File: credentiales_example.json
Email: suraksha.shetty@niveussolutions.com
Repository: https://github.com/suraksha-niveus/scan.git
Timestamp: 2022-05-06 11:38:33 +0530 IST
Line: 6
Commit: 9e5724b5cbfda465dfc00e38c33fa1eb492f9258

