#!/bin/bash
echo "Install kubectl command-line tool"
sudo apt-get install kubectl
kubectl version
echo "Install argoCD"
kubectl create namespace argocd
kubectl get namespace
echo "list out namespace"
kubectl apply -n argocd -f https://raw.githubusercontent.com/argoproj/argo-cd/stable/manifests/install.yaml
# This will create a new namespace, argocd, where Argo CD services and application resources will live.
kubectl get nodes -n argocd
kubectl get svc -n argocd
echo "Change the argocd-server service type to LoadBalancer"
kubectl patch svc argocd-server -n argocd -p '{"spec": {"type": "LoadBalancer"}}'
echo "The API server can then be accessed using exxternal IP and port"
sleep 50
kubectl get svc argocd-server -n argocd
kubectl get svc  argocd-server -n argocd > intake.txt
awk '{print $4}' intake.txt > extract.txt
grep -Eo "(25[0-5]|2[0-4][0-9]|[01]?[0-9][0-9]?)\\.(25[0-5]|2[0-4][0-9]|[01]?[0-9][0-9]?)\\.(25[0-5]|2[0-4][0-9]|[01]?[0-9][0-9]?)\\.(25[0-5]|2[0-4][0-9]|[01]?[0-9][0-9]?)" extract.txt > finalout.txt && ip=$(cat finalout.txt) && aa="http://${ip}" && echo $aa
# argocd --insecure login ${EXTERNAL-IP}:80
# echo " Login Using The CLI"
# initial password for the admin account is auto-generated and stored as clear text in the field password in a secret named argocd-initial-admin-secret in your Argo CD installation namespace
echo "retrieve this password using kubectl command"
pass=$(kubectl -n argocd get secret argocd-initial-admin-secret -o jsonpath="{.data.password}" | base64 -d; echo)
echo "username = admin"
echo "PASSWORD = " $pass
echo "login completed"
echo "DONE!"
