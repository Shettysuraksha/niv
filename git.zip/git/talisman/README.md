# Talisman


A tool to detect and prevent secrets from getting checked in 

What is Talisman ?
Talisman is a tool that installs a hook to your repository to ensure that potential secrets or sensitive information do not leave the developer’s workstation
It validates the outgoing changeset for things that look suspicious - such as potential SSH keys, authorization tokens, private keys etc

Installation
Talisman supports MAC, Linux and windows,It can be set up as  either  a pre-commit  or pre-push hook on the git repositories
It can be installed in 2 ways 

**1.As a git hook as a global git hook template** 
It is a good choice to install Talisman as a global hook template. Talisman will thus be present, not only in your existing git repositories, but also in any new repository that you ‘init’ or ‘clone’.
Although you could choose to install Talisman as pre-commit or a pre-push hook, we recommend installing Talisman as a pre-commit git hook template.

**a)As a pre commit hook  OR**

curl --silent  https://raw.githubusercontent.com/thoughtworks/talisman/master/global_install_scripts/install.bash > /tmp/install_talisman.bash && /bin/bash /tmp/install_talisman.bash

**b)As a pe push hook**

curl --silent  https://raw.githubusercontent.com/thoughtworks/talisman/master/global_install_scripts/install.bash > /tmp/install_talisman.bash && /bin/bash /tmp/install_talisman.bash pre-push

If you do not have TALISMAN_HOME set up in your $PATH, you will be asked an appropriate place to set it up. Choose the option number where you set the profile source on your machine.
Choose a base directory where Talisman should scan for all git repositories, and setup a git hook 


**Running Talisman In local machine**
  
There is no explicit command to run talisman. Talisman will get triggered depending on what  it has been installed as i.e.either as pre-commit or pre-push hook.
  
Step1: Create new Branch (optional)
  
            -git checkout -b <new-branch-name>
  
Step2: Add the changed files for commit
  
            -git add .
  
Step3: Commit the code
  
            -git commit -m "<comment-title>"
  
 it will list down the ERRORS which are matching the secret/credentials pattern in the code repo
—----------------------------------------------------------------------------------------------------------------------------

Talisman Scan: 3 / 3 <-------------------------------------------------------------------------------------------------------------> 100.00%  

Talisman Report:
+---------------------------+-------------------------------------------------+----------+
|           FILE            |                     ERRORS                      | SEVERITY |
+---------------------------+-------------------------------------------------+----------+
| credentiales_example.json | Potential secret pattern                        | low      |
|                           | :     "private_key_id":                         |          |
|                           | "xxxxxxxxxxxxxxxxxxxxxxxxxxxxxxx"               |          |
+---------------------------+-------------------------------------------------+----------+
| credentiales_example.json | Potential secret pattern :                      | low      |
|                           | "private_key": "-----BEGIN PRIVATE              |          |
|                           | KEY-----\nxxxxxxxxxxxxxxxxxxxxxxxxxxx\n-----END |          |
|                           | PRIVATE KEY-----\n"                             |          |
+---------------------------+-------------------------------------------------+----------+


If you are absolutely sure that you want to ignore the above files from talisman detectors, consider pasting the following format in .talismanrc file in the project root

fileignoreconfig:
- filename: credentiales_example.json
  checksum: 6c71df0e4c44f9745c85e5ee5fd7a17765cb61356c65a4f282f44be09cdfe178
version: ""

**Do you want to add credentiales_example.json with above checksum in talismanrc ? (y/N) **
  **N**
  
if you say **N** 
Talisman done in 8.932559ms


—-------------------------------------------------------------------------------------------------------------------------------
**If you want to ignore credentials and commit follow this step** 

Talisman Scan: 3 / 3 <-------------------------------------------------------------------------------------------------------------> 100.00%  

Talisman Report:
+---------------------------+-------------------------------------------------+----------+
|           FILE            |                     ERRORS                      | SEVERITY |
+---------------------------+-------------------------------------------------+----------+
| credentiales_example.json | Potential secret pattern                        | low      |
|                           | :     "private_key_id":                         |          |
|                           | "xxxxxxxxxxxxxxxxxxxxxxxxxxxxxxx"               |          |
+---------------------------+-------------------------------------------------+----------+
| credentiales_example.json | Potential secret pattern :                      | low      |
|                           | "private_key": "-----BEGIN PRIVATE              |          |
|                           | KEY-----\nxxxxxxxxxxxxxxxxxxxxxxxxxxx\n-----END |          |
|                           | PRIVATE KEY-----\n"                             |          |
+---------------------------+-------------------------------------------------+----------+


If you are absolutely sure that you want to ignore the above files from talisman detectors, consider pasting the following format in .talismanrc file in the project root

fileignoreconfig:
- filename: credentiales_example.json
  checksum: 6c71df0e4c44f9745c85e5ee5fd7a17765cb61356c65a4f282f44be09cdfe178
version: ""

**Do you want to add credentiales_example.json with above checksum in talismanrc ? (y/N) **
  **Y**
  
if you say **Y** 
Talisman done in 26.242620901s
[main 2e7b45e] included cred
 2 files changed, 16 insertions(+)
 create mode 100644 .talismanrc
 create mode 100644 credentiales_example.json

** or **


git commit -m --no-verify

[master (root-commit) 6c69ebc] add
 2 files changed, 14 insertions(+)
 create mode 100644 .talismanrc
 create mode 100644 credentiales_example.json





Step4: push code

-git push -u origin


user@IND040100195:~/Documents/session/s2$ git push -u origin master
talisman pre-push hook cannot be invoked in interactive mode currently
Talisman Scan: 3 / 3 <-------------------------------------------------------------------------------------------------------------> 100.00%  

Talisman Report:
+---------------------------+-------------------------------------------------+----------+
|           FILE            |                     ERRORS                      | SEVERITY |
+---------------------------+-------------------------------------------------+----------+
| credentiales_example.json | Potential secret pattern                        | low      |
|                           | :     "private_key_id":                         |          |
|                           | "xxxxxxxxxxxxxxxxxxxxxxxxxxxxxxx"               |          |
+---------------------------+-------------------------------------------------+----------+
| credentiales_example.json | Potential secret pattern :                      | low      |
|                           | "private_key": "-----BEGIN PRIVATE              |          |
|                           | KEY-----\nxxxxxxxxxxxxxxxxxxxxxxxxxxx\n-----END |          |
|                           | PRIVATE KEY-----\n"                             |          |
+---------------------------+-------------------------------------------------+----------+

==== Interactively adding to talismanrc ====

filename: credentiales_example.json
checksum: 6c71df0e4c44f9745c85e5ee5fd7a17765cb61356c65a4f282f44be09cdfe178

? Do you want to add credentiales_example.json with above checksum in talismanrc ? (y/N) 2022/05/15 16:20:20 error occured when getting input from user: EOF
ERRO[0000] Error appending to talismanrc [102 97 116 97 108 58 32 112 97 116 104 115 112 101 99 32 39 46 116 97 108 105 115 109 97 110 114 99 39 32 100 105 100 32 110 111 116 32 109 97 116 99 104 32 97 110 121 32 102 105 108 101 115 10] 
Talisman done in 16.106327ms
error: failed to push some refs to 'git@gitlab.niveussolutions.com:suraksha.shetty/s1.git'

**If you want to ignore credentials and commit follow this step** 

-git push -u origin <new-branch-name> --no-verify

^[[38;142R^[[38;90Ruser@IND040100195:~/Documents/session/s2$ git push -u origin master --no-verify
Enumerating objects: 3, done.
Counting objects: 100% (3/3), done.
Delta compression using up to 8 threads
Compressing objects: 100% (3/3), done.
Writing objects: 100% (3/3), 514 bytes | 257.00 KiB/s, done.
Total 3 (delta 0), reused 0 (delta 0)
To gitlab.niveussolutions.com:suraksha.shetty/s1.git
 * [new branch]      master -> master
Branch 'master' set up to track remote branch 'master' from 'origin'.


**2.As a hook for a single repository**

Download the talisman installer script

curl https://thoughtworks.github.io/talisman/install.sh > ~/install-talisman.sh

chmod +x ~/install-talisman.sh

Install to a single project

cd <project-folder>

as a pre-push hook

~/install-talisman.sh

or as a pre-commit hook

~/install-talisman.sh pre-commit




**Uninstallation**

*1.Uninstallation from a global hook template*
Run the following command on your terminal to uninstall talisman globally from your machine.

*1a)For pre-commit hook:*

curl --silent  https://raw.githubusercontent.com/thoughtworks/talisman/master/global_install_scripts/uninstall.bash > /tmp/uninstall_talisman.bash && /bin/bash /tmp/uninstall_talisman.bash


*1b)For pre-push hook:*

curl --silent  https://raw.githubusercontent.com/thoughtworks/talisman/master/global_install_scripts/uninstall.bash > /tmp/uninstall_talisman.bash && /bin/bash /tmp/uninstall_talisman.bash pre-push

**Uninstallation from a single repository**

When you installed Talisman, it must have created a pre-commit or pre-push hook (as selected) in your repository during installation.
You can remove the hook manually by deleting the Talisman pre-commit or pre-push hook from .git/hooks folder in repository.
/home/user/.git-template/hooks
 
 




