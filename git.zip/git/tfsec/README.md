# tfsec

**tfsec uses static analysis of your terraform code to spot potential misconfigurations**
tfsec is an Aqua Security open source project

1. A static analysis security scanner for your Terraform code that discovers problems with your infrastructure before hackers do,to detect potential security risks
2. tfsec takes a developer-first approach to scanning your Terraform templates,using static analysis and deep integration with the official HCL parser it ensures that security issues can be detected before your infrastructure changes take effect
3. A unique aspect of TFsec is that it examines Terraform code and simulates how resources will be deployed in the cloud, using the Hashicorp HCL engine. This allows it to discover vulnerabilities that other tools miss, because they only scan the code, without looking at the actual final deployment
4. Designed to run locally and in your CI pipelines, easy to integrate into a CI pipeline and has a growing library of checks against all of the major and some minor cloud providers and platforms like Kubernetes
5. developer-friendly output and fully documented checks mean detection and remediation can take place as quickly and efficiently as possible
6. Evaluates HCL expressions as well as literal values
7. Evaluates Terraform functions e.g. concat()
8. Evaluates relationships between Terraform resources
9. Compatible with the Terraform CDK
10. Supports multiple output formats: lovely (default), JSON, SARIF, CSV, CheckStyle, JUnit, text, Gif.
11. capable of quickly scanning huge repositories
12. Plugins for popular IDEs available (JetBrains, VSCode and Vim)
13. The TFSec project has grown to include over built in  150 checks, supporting AWS, Azure, Google Cloud Platform, Digital Ocean, OpenStack, and Cloud Stack,plus several more.
14. there are checks that need performing for an organisation that don't fit with general use cases, for this, there are custom checks,Custom checks offer an accessible approach to injecting checks that satisfy your organisations compliance and security needs


**##Installation**
**###Install with brew/linuxbrew**
```brew install tfsec```

**###Install with Chocolatey**
```choco install tfsec```

**###Install with Scoop**
```scoop install tfsec```

**###Alternatively, install with Go**
```go install github.com/aquasecurity/tfsec/cmd/tfsec@latest```


**##Usage**
**###tfsec will scan the specified directory** 
>If no directory is specified, the current working directory will be used.
>The exit status will be non-zero if tfsec finds problems, otherwise the exit status will be zero.

```tfsec .```

**###Use with Docker**
>As an alternative to installing and running tfsec on your system, you may run tfsec in a Docker container.

**####There are a number of Docker options available**
**Image Name	            Base	Comment**
aquasec/tfsec	            alpine	Normal tfsec image
aquasec/tfsec-alpine	    alpine	Exactly the same as aquasec/tfsec, but for those whole like to be explicit
aquasec/tfsec-ci	        alpine	tfsec with no entrypoint - useful for CI builds where you want to override the command
aquasec/tfsec-scratch	    scratch	An image built on scratch - nothing frilly, just runs tfsec

**To run:**

```docker run --rm -it -v "$(pwd):/src" aquasec/tfsec /src```

**###Use with Visual Studio Code**
VS Code extension is for tfsec
A Visual Studio Code extension is being developed to integrate with tfsec results

**###Use as GitHub Action**
If you want to run tfsec on your repository as a GitHub Action, you can use 

```https://github.com/aquasecurity/tfsec-pr-commenter-action.```

**##Ignoring Warnings**
You may wish to ignore some warnings. If you'd like to do so, you can simply add a comment containing 'tfsec:ignore:<rule>' to the offending line in your templates. Alternatively, you can add the comment to the line above the block containing the issue, or to the module block to ignore all occurrences of an issue inside the module

For example, to ignore an open security group rule
    
    resource "aws_security_group_rule" "my-rule" {
    type = "ingress"
    cidr_blocks = ["0.0.0.0/0"] #tfsec:ignore:aws-vpc-no-public-ingress-sgr
}
    
or

    resource "aws_security_group_rule" "my-rule" {
    type = "ingress"
    #tfsec:ignore:aws-vpc-no-public-ingress-sgr
    cidr_blocks = ["0.0.0.0/0"]
}

    
If you're not sure which line to add the comment on, just check the tfsec output for the line number of the discovered problem
You can ignore multiple rules by concatenating the rules on a single line

    
  tfsec:ignore:aws-s3-enable-bucket-encryption tfsec:ignore:aws-s3-enable-bucket-logging
    
  ```resource "aws_s3_bucket" "my-bucket" {
  bucket = "foobar"
  acl    = "private"
}
```
    
**##Disable checks**
    
You may wish to exclude some checks from running. If you'd like to do so, you can simply add new argument -e check1,check2,etc to your cmd command

```tfsec . -e general-secrets-sensitive-in-variable,google-compute-disk-encryption-customer-keys```


**##Included Checks**
    
tfsec supports many popular cloud and platform providers

>AWS Checks,
>Azure Checks,
>GCP Checks,
>CloudStack Checks,
>DigitalOcean Checks,
>GitHub Checks,
>Kubernetes Checks,
>OpenStack Checks,
>Oracle Checks


