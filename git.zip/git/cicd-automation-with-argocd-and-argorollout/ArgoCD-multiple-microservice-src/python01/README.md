# gitops-demo
gitops-demo
Please follow the video: https://www.youtube.com/watch?v=mhMMNl8mgbY
