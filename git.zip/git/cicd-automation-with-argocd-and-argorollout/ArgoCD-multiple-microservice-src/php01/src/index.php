<?php

echo "welcome all......... <br>";
echo "Hello all !!!!! <br>";
echo '<img src="https://www.docker.com/sites/default/files/horizontal.png">';

?>
