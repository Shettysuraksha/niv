# INTEGRATE TERRAFORM WITH JENKINS PIPELINE AND SCANNING GITCHECKOUT WITH TFSEC AND GITLEAKS
Terraform code to create GCP VM,VPC and firewall and pushed to github repo GCP-VM-VPC
[https://github.com/suraksha-niveus/GCP-VM-VPC.git](url)

**Jenkins install in local machine**
-- install java

$sudo apt install openjdk-11-jdk

$java -version
---instal jenkins

$wget -q -O - https://pkg.jenkins.io/debian/jenkins.io.key | sudo apt-key add -
$sudo sh -c 'echo deb http://pkg.jenkins.io/debian-stable binary/ > /etc/apt/sources.list.d/jenkins.list'
$sudo apt update
$sudo apt install jenkins
$sudo systemctl start jenkins
$sudo systemctl enable jenkins 
$sudo  systemctl status jenkins
$sudo ufw allow 8080
$sudo ufw status
$sudo ufw enable
--You’ll notice that traffic is allowed to port 8080 from anywhere

--To set up your new Jenkins installation, open your browser, type your domain or IP address followed by port
--You should see the Unlock Jenkins screen, that shows the location of the initial password:

http://localhost:8080/

$sudo cat /var/lib/jenkins/secrets/initialAdminPassword

--Copy the password from the terminal, paste it into the “Administrator password” field and click Continue

--On the next screen, the setup wizard will ask you whether you want to install suggested plugins or you want to select specific plugins
--Click on the “Install suggested plugins” box and the installation process will start immediately
--Once the plugins are installed, you will be prompted to set up the first admin user. Fill out all required information and click Save and Continue
--The next page will ask you to set the URL for your Jenkins instance. The field will be populated with an automatically generated URL
--Confirm the URL by clicking on the Save and Finish button, and the setup process will be completed
--At this point, you’ve successfully installed Jenkins on your server.

**Install Terraform plugin**
--In Jenkins console, go to Manage Jenkins > Manage Plugins > Available > search Terraform>install without restart
similarly
--go to Manage Jenkins > Manage Plugins > Available > search docker>install without restart
--From Manage Jenkins > Global Tool Configuration > Terraform>Add Terraform>Uncheck the "Install automatically" checkbox.
    Name: terraform01
    Install directory: /usr/bin/
    
 **Let’s create new project to execute Terraform from Jenkins**
 --Create a New Project
Jenkins -> New Item
Enter an item name: Terraform-pipeline
Choose Pipeline
--There are 2 options for Jenkinsfile, i.e., Pipeline script and Pipeline script From SCM. (Pipeline Script: You can write your Pipeline code directly on Jenkins job)
https://github.com/suraksha-niveus/GCP-VM-VPC.git
In pipeline add script which present in Jenkinsfile apply and save
Execute (Build Now) the Jenkins pipeline.




