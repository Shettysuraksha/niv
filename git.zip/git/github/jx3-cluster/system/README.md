# System


This directory contains system configs such as the repo version and how resources are synced.
