## Jenkins Support

This folder contains files to help import source repositories into Jenkins servers via GitOps

* [templates](templates) contains go templates for the [Job DSL](https://github.com/jenkinsci/job-dsl-plugin/wiki/Job-DSL-Commands#dsl-methods) to generate folders and jobs for Jenkins servers