## Job DSL Templates

This folder contains go templates to generate [Job DSL](https://github.com/jenkinsci/job-dsl-plugin/wiki/Job-DSL-Commands#dsl-methods) to generate folders and jobs for Jenkins servers