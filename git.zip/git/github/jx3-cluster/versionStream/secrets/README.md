## Secret Mappings

This directory contains the default secret mappings files which are typically imported into a gitops repository at `.jx/secret/secret-mappings.yaml`