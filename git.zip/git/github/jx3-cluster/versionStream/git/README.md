## Git Repositories

This directory tree contains the version of git repositories used no explicit version is specified.

the file layout is `[gitServer]/[owner]/repositoryName.yml` with the YAML file containing a `version:` property and an optional `gitUrl:` URL of where the repository is.


e.g.

* [github.com](github.com)/[jenkins-x-buildpacks](github.com/jenkins-x-buildpacks)/[jenkins-x-kubernetes.yml](github.com/jenkins-x-buildpacks/jenkins-x-kubernetes.yml)

