## Git Operator Job Resources

This folder defines the additional resources (such as [ServiceAccount](sa.yaml) and the RBAC resources (`Roles`, `RoleBindings`, `ClusterRole`, `ClusterRoleBinding`) for the  [Job YAML](../job.yaml) for the [jenkins-x/jx-git-operator](https://github.com/jenkins-x/jx-git-operator)