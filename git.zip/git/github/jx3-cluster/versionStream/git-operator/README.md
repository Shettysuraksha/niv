## Git Operator Job

This folder defines the [Job YAML](job.yaml) for the [jenkins-x/jx-git-operator](https://github.com/jenkins-x/jx-git-operator)