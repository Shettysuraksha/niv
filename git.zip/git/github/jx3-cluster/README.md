# Jenkins X 3.x GitOps Repository for GKE and Google Secret Manager

This git repository installs Jenkins X with Google Secret Manager.

## Creating/upgrading cloud resources

Modify the `jx-requirements.yml` file

Now git commit and push any changes...

```bash 
git add *
git commit -a -m "chore: Jenkins X changes"
```
