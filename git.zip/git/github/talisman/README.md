# talisman
---Talisman - Security Check,Prevent Committing Secrets and Credentials into Github Repos!

---Talisman is a tool that installs a hook to your repository to ensure that potential secrets or sensitive information do not leave the developer’s workstation. It validates the outgoing changeset for things that look suspicious - such as potential SSH keys, authorization tokens, private keys etc

***Installation***

**1.As a global installation**
---talisman will install as a git hook as a global git hook template on the machine and a CLI utility, which can also be used for git repo scanning. The git hook can be set up for either a pre-commit or a pre-push configuration

**(a) Use the below command on terminal to run Talisman as pre-commit hook**

***$ curl --silent  https://raw.githubusercontent.com/thoughtworks/talisman/master/global_install_scripts/install.bash > /tmp/install_talisman.bash && /bin/bash /tmp/install_talisman.bash***

**(b) Use the below command on terminal to run Talisman as pre-push hook**

***$ curl --silent  https://raw.githubusercontent.com/thoughtworks/talisman/master/global_install_scripts/install.bash > /tmp/install_talisman.bash && /bin/bash /tmp/install_talisman.bash pre-push***

--If you do not have TALISMAN_HOME set up in your $PATH, you will be asked an appropriate place to set it up. Choose the option number where you set the profile source on your machine, Remember to execute source on the path file or restart your terminal. If you choose to set the $PATH later, add export TALISMAN\_HOME=$HOME/.talisman/bin to the path

better to choose a base directory where Talisman should scan for all git repositories, and setup a git hook (pre-commit or pre-push)

**2 As a hook for a single repository**

Download the talisman installer script

$ curl https://thoughtworks.github.io/talisman/install.sh > ~/install-talisman.sh

$ chmod +x ~/install-talisman.sh

Install to a single project

cd <project-folder>
  
as a pre-push hook
  
~/install-talisman.sh
  
or as a pre-commit hook
  
~/install-talisman.sh pre-commit
  
# Running Talisman
  
There is no explicit command to run talisman. Talisman will get triggered depending on WHAT it has been installed as i.e.either as pre-commit or pre-push hook.
  
-Step1: Create new Branch (optional)
  
-git checkout -b <new-branch-name>
  
-Step2: Add the changed files for commit
  
-git add .
  
-Step3: Commit the code
  
-git commit -m "<comment-title>"
  
 it will list down the ERRORS which are matching the secret/credentials pattern in the code repo
  ----------------------------------------------------------------------------------------------------------------------------------------
**pre commit result**
  
user@IND040100195:~/Documents/work/talisman$ git commit -m "first commit"
Talisman Scan: 15 / 15 <-----------------------------------------------------------------------------------------------------------> 100.00%  

Talisman Report:
+---------------------------+-------------------------------------------------+----------+
|           FILE            |                     ERRORS                      | SEVERITY |
+---------------------------+-------------------------------------------------+----------+
| README.md                 | Potential secret pattern :                      | low      |
|                           | credentiales_example.json:4:                    |          |
|                           |    "private_key_id":                            |          |
|                           | "xxxxxxxxxxxxxxxxxxxxxxxxxxxxxxx"               |          |
+---------------------------+-------------------------------------------------+----------+
| README.md                 | Potential secret pattern :                      | low      |
|                           | credentiales_example.json:5:                    |          |
|                           | "private_key": " -----BEGIN PRIVATE             |          |
|                           | KEY-----\nxxxxxxxxxxxxxxxxxxxxxxxxxxx\n-----END |          |
|                           | PRIVA...                                        |          |
+---------------------------+-------------------------------------------------+----------+
| credentiales_example.json | Potential secret pattern                        | low      |
|                           | :     "private_key_id":                         |          |
|                           | "xxxxxxxxxxxxxxxxxxxxxxxxxxxxxxx"               |          |
+---------------------------+-------------------------------------------------+----------+
| credentiales_example.json | Potential secret pattern :                      | low      |
|                           | "private_key": "-----BEGIN PRIVATE              |          |
|                           | KEY-----\nxxxxxxxxxxxxxxxxxxxxxxxxxxx\n-----END |          |
|                           | PRIVATE KEY-----\n"                             |          |
+---------------------------+-------------------------------------------------+----------+


If you are absolutely sure that you want to ignore the above files from talisman detectors, consider pasting the following format in .talismanrc file in the project root

fileignoreconfig:
- filename: README.md
  checksum: 31c3623ac1480d46f1b60818230b3c155dd7b3214b5b57d93b338da3ec47e389
- filename: credentiales_example.json
  checksum: 6c71df0e4c44f9745c85e5ee5fd7a17765cb61356c65a4f282f44be09cdfe178
version: ""
  
   **Do you want to add credentiales_example.json with above checksum in talismanrc ? (y/N) **
  **N**
  
if you say **N** 

Talisman done in 13.466879ms

 ----------------------------------------------------------------------------------------------------------------------------------------  
**OR**
**If you want to ignore credentials and commit follow this step**  
git commit -m "included cred"
Talisman Scan: 3 / 3 <-------------------------------------------------------------------------------------------------------------> 100.00%  

Talisman Report:
+---------------------------+-------------------------------------------------+----------+
|           FILE            |                     ERRORS                      | SEVERITY |
+---------------------------+-------------------------------------------------+----------+
| credentiales_example.json | Potential secret pattern                        | low      |
|                           | :     "private_key_id":                         |          |
|                           | "xxxxxxxxxxxxxxxxxxxxxxxxxxxxxxx"               |          |
+---------------------------+-------------------------------------------------+----------+
| credentiales_example.json | Potential secret pattern :                      | low      |
|                           | "private_key": "-----BEGIN PRIVATE              |          |
|                           | KEY-----\nxxxxxxxxxxxxxxxxxxxxxxxxxxx\n-----END |          |
|                           | PRIVATE KEY-----\n"                             |          |
+---------------------------+-------------------------------------------------+----------+

==== Interactively adding to talismanrc ====

filename: credentiales_example.json
checksum: 6c71df0e4c44f9745c85e5ee5fd7a17765cb61356c65a4f282f44be09cdfe178

**? Do you want to add credentiales_example.json with above checksum in talismanrc ? Yes**
  -------------------------------------------------------------------------------------------------------------------------------------------------
  **Ignore crdential and commit**
  
  $ git commit -m --no-verify

Talisman done in 26.242620901s
[main 2e7b45e] included cred
 2 files changed, 16 insertions(+)
 create mode 100644 .talismanrc
 create mode 100644 credentiales_example.json

 -------------------------------------------------------------------------------------------------------------------------------------
**pre push result **
  
  ser@IND040100195:~/Documents/work/talisman$ git push -u origin main 
Username for 'https://github.com': suraksha-niveus
Password for 'https://suraksha-niveus@github.com': 
Talisman Scan: 15 / 15 <-----------------------------------------------------------------------------------------------------------> 100.00%  

Talisman Report:
+---------------------------+-------------------------------------------------+----------+
|           FILE            |                     ERRORS                      | SEVERITY |
+---------------------------+-------------------------------------------------+----------+
| README.md                 | Potential secret pattern :                      | low      |
|                           | credentiales_example.json:4:                    |          |
|                           |    "private_key_id":                            |          |
|                           | "xxxxxxxxxxxxxxxxxxxxxxxxxxxxxxx"               |          |
+---------------------------+-------------------------------------------------+----------+
| README.md                 | Potential secret pattern :                      | low      |
|                           | credentiales_example.json:5:                    |          |
|                           | "private_key": " -----BEGIN PRIVATE             |          |
|                           | KEY-----\nxxxxxxxxxxxxxxxxxxxxxxxxxxx\n-----END |          |
|                           | PRIVA...                                        |          |
+---------------------------+-------------------------------------------------+----------+
| credentiales_example.json | Potential secret pattern                        | low      |
|                           | :     "private_key_id":                         |          |
|                           | "xxxxxxxxxxxxxxxxxxxxxxxxxxxxxxx"               |          |
+---------------------------+-------------------------------------------------+----------+
| credentiales_example.json | Potential secret pattern :                      | low      |
|                           | "private_key": "-----BEGIN PRIVATE              |          |
|                           | KEY-----\nxxxxxxxxxxxxxxxxxxxxxxxxxxx\n-----END |          |
|                           | PRIVATE KEY-----\n"                             |          |
+---------------------------+-------------------------------------------------+----------+


If you are absolutely sure that you want to ignore the above files from talisman detectors, consider pasting the following format in .talismanrc file in the project root

fileignoreconfig:
- filename: README.md
  checksum: 31c3623ac1480d46f1b60818230b3c155dd7b3214b5b57d93b338da3ec47e389
- filename: credentiales_example.json
  checksum: 6c71df0e4c44f9745c85e5ee5fd7a17765cb61356c65a4f282f44be09cdfe178
version: ""

Talisman done in 24.205464ms

 --------------------------------------------------------------------------------------------------------------------------------------- 
**If no credential present in pre-commit and pre-push then result:**
  
user@IND040100195:~/Desktop/talisman$ git commit -m "first commit"
Talisman Scan: 12 / 12 <-----------------------------------------------------------------------------------------------------------> 100.00%  
Talisman done in 8.642036ms
[master (root-commit) 62eba39] first commit
 4 files changed, 62 insertions(+)
 create mode 100644 README.md
 create mode 100644 main.tf
 create mode 100644 provider.tf
 create mode 100644 variable.tf
user@IND040100195:~/Desktop/talisman$ git branch -M main
user@IND040100195:~/Desktop/talisman$ git remote add origin https://github.com/suraksha-niveus/talisman.git
user@IND040100195:~/Desktop/talisman$ git push -u origin main
Username for 'https://github.com': suraksha-niveus
Password for 'https://suraksha-niveus@github.com': 
talisman pre-push hook cannot be invoked in interactive mode currently
Talisman Scan: 12 / 12 <-----------------------------------------------------------------------------------------------------------> 100.00%  
Talisman done in 19.909799ms
Enumerating objects: 6, done.
Counting objects: 100% (6/6), done.
Delta compression using up to 8 threads
Compressing objects: 100% (5/5), done.
Writing objects: 100% (6/6), 1.05 KiB | 1.05 MiB/s, done.
Total 6 (delta 0), reused 0 (delta 0)
To https://github.com/suraksha-niveus/talisman.git
 * [new branch]      main -> main
Branch 'main' set up to track remote branch 'main' from 'origin'.
