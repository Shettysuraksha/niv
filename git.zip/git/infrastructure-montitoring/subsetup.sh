#!/bin/bash
prometheus_url=$(kubectl get svc prometheus-service -o jsonpath='{.status.loadBalancer.ingress[0].ip}:{.spec.ports[0].port}')
echo "Prometheus URL: http://$prometheus_url"

grafana_url=$(kubectl get svc grafana -o jsonpath='{.status.loadBalancer.ingress[0].ip}:{.spec.ports[0].port}')
echo "Grafana URL: http://$grafana_url"

grafana_url="http://$grafana_url"
prometheus_url="http://$prometheus_url"
cd Infra-monitoring-setup
dashboard_files=("k8s-views-global.json" "kubernetes-monitoring_rev1 (2).json"  "k8s-addons-prometheus.json"  "k8s-addons-trivy-operator.json" "k8s-system-api-server.json" "k8s-system-coredns.json" "k8s-views-namespaces.json" 
"k8s-views-nodes.json" "k8s-views-pods.json"
)
folder_name="General"
datasource_name="Prometheus-database"

# Function to create Prometheus datasource
create_prometheus_datasource() {
    existing_datasource=$(curl -s -u admin:admin "$grafana_url/api/datasources" | jq '.[].name' | grep -E '^"Prometheus-database"$')
    if [[ -n $existing_datasource ]]; then
        datasource_id=$(curl -s -u admin:admin "$grafana_url/api/datasources" | jq '.[] | select(.name == "Prometheus-database") | .id')
        curl -s -X DELETE -u admin:admin "$grafana_url/api/datasources/$datasource_id"
    fi

    curl -s -X POST -u admin:admin -H "Content-Type: application/json" -d '{
        "name": "Prometheus-database",
        "type": "prometheus",
        "url": "'$prometheus_url'",
        "access": "proxy",
        "isDefault": true
    }' "$grafana_url/api/datasources"

    echo "Prometheus data source created successfully."
}

# Create Prometheus datasource
create_prometheus_datasource

# Function to import Grafana dashboard from JSON file
import_dashboard() {
    local file="$1"

    # Read the JSON file
    json_data=$(cat "$file")

    # Extract dashboard UID from the JSON file
    dashboard_uid=$(jq -r '.dashboard.uid' "$file")

    # Extract dashboard name from the file name
    dashboard_name=$(basename "$file" | cut -d. -f1)

    # Prepare the payload data
payload="{\"dashboard\": $json_data, \"folderId\": 0, \"overwrite\": true, \"inputs\": [{\"name\": \"DS_PROMETHEUS\", \"type\": \"datasource\", \"pluginId\": \"prometheus\", \"value\": \"$datasource_name\"}]}"

    # Send the POST request to import the dashboard
    response=$(curl -s -u admin:admin -X POST -H "Content-Type: application/json" -d "$payload" "$grafana_url/api/dashboards/import")

 if [[ $response == *"imported"* ]]; then
        echo "Dashboard '$dashboard_name' imported successfully!"
    else
        echo "Failed to import dashboard '$dashboard_name'."
        echo "Response: $response"
    fi
}

# Import Grafana dashboards
for file in "${dashboard_files[@]}"; do
    import_dashboard "$file"
done
