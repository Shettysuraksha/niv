#!/bin/bash
echo "Clone GitHub repository"
git clone https://github.com/suraksha-niveus/Infra-monitoring-setup.git
# Change directory to cloned repository
cd Infra-monitoring-setup
# Create cluster roles
echo "Creating cluster roles..."
kubectl create clusterrolebinding admin-cluster-admin-binding --clusterrole=cluster-admin --user=admin@niveussolutions.com

# Setup for Prometheus
echo "Setting up Prometheus..."
kubectl apply -f kubernetes-prometheus/

# Setting up Kube State Metrics
echo "Setting up Kube State Metrics..."
kubectl apply -f kube-state-metrics-configs/

# Setting up Alertmanager
echo "Setting up Alertmanager..."
kubectl apply -f kubernetes-alert-manager/

# Setting up Grafana
echo "Setting up Grafana..."
kubectl apply -f kubernetes-grafana/

# Setting up Node Exporter
echo "Setting up Node Exporter..."
kubectl apply -f kubernetes-node-exporter/

# Sleep for 100 seconds to allow the services to start
echo "Sleeping for 100 seconds to allow the services to start..."
sleep 150

# Get service information
echo "Getting service information..."
kubectl get svc

# Retrieve URLs with port for each service
echo "Retrieving URLs with port for each service..."
prometheus_url=$(kubectl get svc prometheus-service -o jsonpath='{.status.loadBalancer.ingress[0].ip}:{.spec.ports[0].port}')
echo "Prometheus URL: http://$prometheus_url"

grafana_url=$(kubectl get svc grafana -o jsonpath='{.status.loadBalancer.ingress[0].ip}:{.spec.ports[0].port}')
echo "Grafana URL: http://$grafana_url"

node_exporter_url=$(kubectl get svc node-exporter -o jsonpath='{.status.loadBalancer.ingress[0].ip}:{.spec.ports[0].port}')
echo "Node Exporter URL: http://$node_exporter_url"

alertmanager_url=$(kubectl get svc alertmanager -o jsonpath='{.status.loadBalancer.ingress[0].ip}:{.spec.ports[0].port}')
echo "Alertmanager URL: http://$alertmanager_url"

existing_datasource=$(curl -s -u admin:admin "http://$grafana_url/api/datasources" | jq '.[].name' | grep -E '^"Prometheus-database"$')
if [[ -z $existing_datasource ]]; then
  curl -X POST -u admin:admin -H "Content-Type: application/json" -d '{
    "name": "Prometheus-database",
    "type": "prometheus",
    "url": "http://'$prometheus_url'",
    "access": "proxy",
    "isDefault": true
  }' "http://$grafana_url/api/datasources"
  echo "Prometheus data source created successfully."
else
  echo "Prometheus data source already exists."
fi

# Call the dashboard configuration script
cd ..
source ./subsetup.sh

echo "Script execution complete."
echo "Dashboard URL: $grafana_url/dashboards"
