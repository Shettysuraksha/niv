# kubernetes-alert-manager
Alert Manager Manifests for Kubnernetes
